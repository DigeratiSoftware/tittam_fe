var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/route.js")
R.c("server/chunks/[root-of-the-server]__f7c0750c._.js")
R.c("server/chunks/[root-of-the-server]__59b23a11._.js")
R.c("server/chunks/b38c2_tittam_fe__next-internal_server_app_api_notifications_route_actions_1ac6110b.js")
R.m(16021)
module.exports=R.m(16021).exports
