var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__b4da3a71._.js")
R.c("server/chunks/[root-of-the-server]__59b23a11._.js")
R.c("server/chunks/75f75_fe__next-internal_server_app_api_notifications_[id]_route_actions_1b1fbdb8.js")
R.m(79414)
module.exports=R.m(79414).exports
