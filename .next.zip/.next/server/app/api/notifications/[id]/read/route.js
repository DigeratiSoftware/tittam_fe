var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/[id]/read/route.js")
R.c("server/chunks/[root-of-the-server]__3b79d94f._.js")
R.c("server/chunks/[root-of-the-server]__59b23a11._.js")
R.c("server/chunks/75f75_fe__next-internal_server_app_api_notifications_[id]_read_route_actions_56da1f27.js")
R.m(5952)
module.exports=R.m(5952).exports
