var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/read-all/route.js")
R.c("server/chunks/[root-of-the-server]__a5ea5f1a._.js")
R.c("server/chunks/[root-of-the-server]__59b23a11._.js")
R.c("server/chunks/75f75_fe__next-internal_server_app_api_notifications_read-all_route_actions_6c2ef034.js")
R.m(11719)
module.exports=R.m(11719).exports
