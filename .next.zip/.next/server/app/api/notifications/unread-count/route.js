var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/unread-count/route.js")
R.c("server/chunks/[root-of-the-server]__2d73578a._.js")
R.c("server/chunks/[root-of-the-server]__59b23a11._.js")
R.c("server/chunks/ce974__next-internal_server_app_api_notifications_unread-count_route_actions_6710be7d.js")
R.m(28787)
module.exports=R.m(28787).exports
