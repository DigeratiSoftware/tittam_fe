var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/all/route.js")
R.c("server/chunks/[root-of-the-server]__6c9064d1._.js")
R.c("server/chunks/[root-of-the-server]__59b23a11._.js")
R.c("server/chunks/75f75_fe__next-internal_server_app_api_notifications_all_route_actions_3530c9b3.js")
R.m(50108)
module.exports=R.m(50108).exports
