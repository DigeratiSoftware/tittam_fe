var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/reports/dashboard/route.js")
R.c("server/chunks/[root-of-the-server]__a84ff9c9._.js")
R.c("server/chunks/[root-of-the-server]__59b23a11._.js")
R.c("server/chunks/75f75_fe__next-internal_server_app_api_reports_dashboard_route_actions_d1631f38.js")
R.m(11388)
module.exports=R.m(11388).exports
