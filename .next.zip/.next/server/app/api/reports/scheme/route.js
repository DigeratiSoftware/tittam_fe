var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/reports/scheme/route.js")
R.c("server/chunks/[root-of-the-server]__3fe3a305._.js")
R.c("server/chunks/[root-of-the-server]__59b23a11._.js")
R.c("server/chunks/b38c2_tittam_fe__next-internal_server_app_api_reports_scheme_route_actions_a8917918.js")
R.m(59383)
module.exports=R.m(59383).exports
