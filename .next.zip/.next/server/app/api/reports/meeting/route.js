var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/reports/meeting/route.js")
R.c("server/chunks/[root-of-the-server]__06079bb8._.js")
R.c("server/chunks/[root-of-the-server]__59b23a11._.js")
R.c("server/chunks/b38c2_tittam_fe__next-internal_server_app_api_reports_meeting_route_actions_9f10b211.js")
R.m(37660)
module.exports=R.m(37660).exports
