module.exports=[52136,(e,o,d)=>{}];

//# sourceMappingURL=75f75_fe__next-internal_server_app_api_notifications_%5Bid%5D_read_route_actions_56da1f27.js.map