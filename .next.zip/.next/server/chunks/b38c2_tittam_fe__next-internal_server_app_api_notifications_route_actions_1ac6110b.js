module.exports=[98137,(e,o,d)=>{}];

//# sourceMappingURL=b38c2_tittam_fe__next-internal_server_app_api_notifications_route_actions_1ac6110b.js.map