module.exports=[2344,(e,o,d)=>{}];

//# sourceMappingURL=b38c2_tittam_fe__next-internal_server_app_api_reports_meeting_route_actions_9f10b211.js.map