module.exports=[31756,(e,o,d)=>{}];

//# sourceMappingURL=75f75_fe__next-internal_server_app_api_notifications_%5Bid%5D_route_actions_1b1fbdb8.js.map