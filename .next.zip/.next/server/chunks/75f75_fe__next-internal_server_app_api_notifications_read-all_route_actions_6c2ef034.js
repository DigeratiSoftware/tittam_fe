module.exports=[97612,(e,o,d)=>{}];

//# sourceMappingURL=75f75_fe__next-internal_server_app_api_notifications_read-all_route_actions_6c2ef034.js.map