module.exports=[24167,(a,b,c)=>{}];

//# sourceMappingURL=projects_TITTAM_tittam_fe__next-internal_server_app_page_actions_8e3a84c2.js.map