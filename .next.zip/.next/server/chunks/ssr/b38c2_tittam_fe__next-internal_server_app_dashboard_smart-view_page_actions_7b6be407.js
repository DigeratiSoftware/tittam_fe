module.exports=[79177,(a,b,c)=>{}];

//# sourceMappingURL=b38c2_tittam_fe__next-internal_server_app_dashboard_smart-view_page_actions_7b6be407.js.map