module.exports=[52345,(a,b,c)=>{}];

//# sourceMappingURL=9e3a1_TITTAM_tittam_fe__next-internal_server_app__global-error_page_actions_4aab1f7f.js.map