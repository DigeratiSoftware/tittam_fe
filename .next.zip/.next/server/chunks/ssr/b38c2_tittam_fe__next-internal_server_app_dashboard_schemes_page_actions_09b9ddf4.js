module.exports=[26962,(a,b,c)=>{}];

//# sourceMappingURL=b38c2_tittam_fe__next-internal_server_app_dashboard_schemes_page_actions_09b9ddf4.js.map