module.exports=[38790,(a,b,c)=>{}];

//# sourceMappingURL=b38c2_tittam_fe__next-internal_server_app_dashboard_contractors_page_actions_a11c6dc9.js.map