module.exports=[72836,(a,b,c)=>{}];

//# sourceMappingURL=b38c2_tittam_fe__next-internal_server_app_dashboard_work_create_page_actions_d2e4efbe.js.map