module.exports=[60529,(a,b,c)=>{}];

//# sourceMappingURL=b38c2_tittam_fe__next-internal_server_app_dashboard_templates_page_actions_7b819e8b.js.map