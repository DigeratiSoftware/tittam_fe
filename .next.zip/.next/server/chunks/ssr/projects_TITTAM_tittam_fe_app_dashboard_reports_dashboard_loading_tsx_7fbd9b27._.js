module.exports=[20915,a=>{"use strict";var b=a.i(20100);function c(){return(0,b.jsx)("div",{className:"flex items-center justify-center h-screen",children:(0,b.jsx)("div",{className:"animate-spin rounded-full h-8 w-8 border-b-2 border-[#013A65]"})})}a.s(["default",()=>c])}];

//# sourceMappingURL=projects_TITTAM_tittam_fe_app_dashboard_reports_dashboard_loading_tsx_7fbd9b27._.js.map