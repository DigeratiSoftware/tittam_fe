module.exports=[35272,(a,b,c)=>{}];

//# sourceMappingURL=b38c2_tittam_fe__next-internal_server_app_dashboard_info-hub_page_actions_41bbd040.js.map