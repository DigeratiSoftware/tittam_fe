module.exports=[22064,(a,b,c)=>{}];

//# sourceMappingURL=ce974__next-internal_server_app_dashboard_smart-sheets_create_page_actions_50c0a0f2.js.map