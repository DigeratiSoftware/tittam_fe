module.exports=[36781,(a,b,c)=>{}];

//# sourceMappingURL=9e3a1_TITTAM_tittam_fe__next-internal_server_app_dashboard_page_actions_9fb63468.js.map