module.exports=[20960,(a,b,c)=>{}];

//# sourceMappingURL=75f75_fe__next-internal_server_app_dashboard_reports_scheme_page_actions_a5ff4189.js.map