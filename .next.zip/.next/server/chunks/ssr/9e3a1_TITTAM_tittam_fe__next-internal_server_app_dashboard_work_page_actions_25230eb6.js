module.exports=[7051,(a,b,c)=>{}];

//# sourceMappingURL=9e3a1_TITTAM_tittam_fe__next-internal_server_app_dashboard_work_page_actions_25230eb6.js.map