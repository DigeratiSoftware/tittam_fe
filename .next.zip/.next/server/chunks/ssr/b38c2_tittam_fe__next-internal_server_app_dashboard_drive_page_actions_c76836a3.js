module.exports=[38197,(a,b,c)=>{}];

//# sourceMappingURL=b38c2_tittam_fe__next-internal_server_app_dashboard_drive_page_actions_c76836a3.js.map