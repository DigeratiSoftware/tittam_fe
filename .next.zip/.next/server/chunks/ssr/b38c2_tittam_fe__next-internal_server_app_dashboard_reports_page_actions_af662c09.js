module.exports=[37898,(a,b,c)=>{}];

//# sourceMappingURL=b38c2_tittam_fe__next-internal_server_app_dashboard_reports_page_actions_af662c09.js.map