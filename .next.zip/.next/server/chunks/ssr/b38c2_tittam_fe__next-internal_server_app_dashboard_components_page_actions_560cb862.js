module.exports=[1821,(a,b,c)=>{}];

//# sourceMappingURL=b38c2_tittam_fe__next-internal_server_app_dashboard_components_page_actions_560cb862.js.map