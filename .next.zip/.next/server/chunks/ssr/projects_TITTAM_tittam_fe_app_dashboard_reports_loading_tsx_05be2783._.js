module.exports=[30435,a=>{"use strict";function b(){return null}a.s(["default",()=>b])}];

//# sourceMappingURL=projects_TITTAM_tittam_fe_app_dashboard_reports_loading_tsx_05be2783._.js.map