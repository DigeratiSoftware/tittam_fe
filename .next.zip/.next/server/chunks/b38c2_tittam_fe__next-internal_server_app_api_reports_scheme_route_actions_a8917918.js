module.exports=[32762,(e,o,d)=>{}];

//# sourceMappingURL=b38c2_tittam_fe__next-internal_server_app_api_reports_scheme_route_actions_a8917918.js.map